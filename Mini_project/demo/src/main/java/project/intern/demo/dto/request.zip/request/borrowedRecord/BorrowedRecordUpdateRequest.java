package project.intern.demo.dto.request.borrowedRecord;

import project.intern.demo.entity.Book;
import project.intern.demo.entity.User;

import java.time.LocalDate;

public class BorrowedRecordUpdateRequest {
    private LocalDate borrowDate;
    private LocalDate returnDate;
    private String status;
    private int user_id;
    private int book_id;

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }
}
